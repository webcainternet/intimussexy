<?php
// Heading
$_['heading_title'] = 'Ofertas';

// Text
$_['text_tax']      = 'Ex Tax:';

				$_['text_view']          = 'Ver promoções';
