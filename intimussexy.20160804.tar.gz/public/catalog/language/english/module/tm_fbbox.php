<?php
// Heading
$_['heading_title']    = 'Facebook Box';

// Text
$_['text_edit']        = 'Edit Account';
