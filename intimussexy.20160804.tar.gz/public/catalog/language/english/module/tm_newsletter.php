<?php
// Heading
$_['heading_title'] = 'Newsletter';

// Entry
$_['entry_mail'] = 'Digite seu e-mail';

// Text
$_['button_subscribe']      = 'Inscrever-se';
$_['text_success'] = 'Você foi inscrito com sucesso';

//Errors
$_['error_exist_user'] = 'Usuário já registrado';
$_['error_exist_email'] = 'E-mail já registrado';
$_['error_invalid_email'] = 'Por favor digite um e-mail válido!';