<?php
// Heading
$_['heading_title'] = 'Promoções';

// Text
$_['text_tax']      = 'Sem impostos:';

				$_['text_view']          = 'Ver promoções';

