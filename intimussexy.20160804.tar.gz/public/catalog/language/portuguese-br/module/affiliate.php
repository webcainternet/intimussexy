<?php
// Heading
$_['heading_title']    = 'Programa de afiliados';

// Text
$_['text_register']    = 'Cadastre-se';
$_['text_login']       = 'Acessar';
$_['text_logout']      = 'Sair';
$_['text_forgotten']   = 'Solicitar nova senha';
$_['text_account']     = 'Minha conta';
$_['text_edit']        = 'Informações da conta';
$_['text_password']    = 'Modificar senha';
$_['text_payment']     = 'Informações para comissões';
$_['text_tracking']    = 'Gerador de links';
$_['text_transaction'] = 'Histórico de pagamentos';
