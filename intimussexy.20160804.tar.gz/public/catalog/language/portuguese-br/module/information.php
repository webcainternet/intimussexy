<?php
// Heading
$_['heading_title'] = 'Informações';

// Text
$_['text_contact']  = 'Contato';
$_['text_sitemap']  = 'Mapa do site';