<?php
// Heading
$_['heading_title']    = 'Manutenção';

// Text
$_['text_maintenance'] = 'Manutenção';
$_['text_message']     = '<h1 style="text-align:center;">No momento estamos realizando uma manutenção agendada. <br/>Estaremos de volta o mais rápido possível.</h1>';