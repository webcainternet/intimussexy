<?php
// Text
$_['text_title']				= 'Cheque';
$_['text_instruction']			= 'Instruções para o pagamento por cheque';
$_['text_payable']				= 'Nominal a: ';
$_['text_address']				= 'Enviar para: ';
$_['text_payment']				= 'Seu pedido será enviado assim que recebermos e descontarmos o cheque.';