<?php
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'Atenção: O pagamento está em modo de teste. Sua conta não será carregada.';
$_['text_total']	= 'Frete, descontos, impostos e taxas';