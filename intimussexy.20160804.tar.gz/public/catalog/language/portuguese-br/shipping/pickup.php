<?php
// Text
$_['text_title']       = 'Retirada';
$_['text_description'] = 'Retirar na loja';