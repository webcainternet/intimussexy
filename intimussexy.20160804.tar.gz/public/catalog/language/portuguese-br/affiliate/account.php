<?php
// Heading
$_['heading_title']        = 'Minha conta de afiliado';

// Text
$_['text_account']         = 'Programa de afiliados';
$_['text_my_account']      = 'Minha conta';
$_['text_my_tracking']     = 'Ferramenta';
$_['text_my_transactions'] = 'Minhas comissões';
$_['text_edit']            = 'Informações da conta';
$_['text_password']        = 'Modificar senha';
$_['text_payment']         = 'Informações para comissões';
$_['text_tracking']        = 'Gerador de links';
$_['text_transaction']     = 'Histórico de pagamentos';