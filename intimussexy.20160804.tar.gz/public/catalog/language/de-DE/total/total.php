<?php
/**
 * @version		$Id: total.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['text_total'] = 'Gesamt';