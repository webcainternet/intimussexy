<?php
/**
 * @version		$Id: login.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Language Translation german
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_success']	= 'API-Sitzung erfolgreich gestartet';

// Error
$_['error_login'] 	= 'Hinweis: kein Treffer für Name und/oder Passwort';